import axios from 'axios';

const axiosOrders = axios.create({
  baseURL: 'url-to-your-firebase'
});

export default axiosOrders;
